# envato-child
Extension to envato-market for downloading full package and upgrading nested plugin
